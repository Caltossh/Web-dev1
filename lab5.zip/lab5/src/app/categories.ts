export const categories=[
    'phone','laptop','TV','Home'
]
